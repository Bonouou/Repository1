/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicazionetrapeer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author gabri
 */
public class ComunicazioneTraPeer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("inserire porta e nome del peer 1");
       // ThreadMandaMessaggio t1 = new ThreadMandaMessaggio();
        
       // t1.run();
        
    }
    
}
