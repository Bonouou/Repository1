/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicazionetrapeer;

import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
 *
 * @author gabri
 */
public class ThreadMandaMessaggio {
    DatagramSocket server;
    DatagramPacket dp;
    boolean running;
    
     public void close() {
        running = false;
    }
     public void run() throws IOException {
        byte[] data = new byte[1024];
        dp = new DatagramPacket(data, data.length);
        running = true;
     server=new DatagramSocket(667);
         System.out.println("connessione sulla porta 667");
         System.out.println("inserire il nome del peer mittente");
        Scanner m = new Scanner(System.in);
         System.out.println("inserire il nome del peer destinatario");
         Scanner d = new Scanner(System.in);
        while (running) {
       
                server.receive(dp); // ricevo numero 
           
            data = dp.getData();

            String temp = new String(data);
            String[] campi = temp.split(";");
            if (campi.length > 1) {
                if (Float.parseFloat(campi[0]) > -81 && Float.parseFloat(campi[0]) < 81) {
                    if (Integer.parseInt(campi[1].replaceAll("\\P{Print}", "")) > -1 && Integer.parseInt(campi[1].replaceAll("\\P{Print}", "")) < 101) {
                       
                    } else {
                      
                    }
                    System.out.println("RICEVUTO CON SUCCESSO");
                } else {
                    data = ("ERRORE").getBytes();
                 
                        dp = new DatagramPacket(data, data.length, InetAddress.getByName("localhost"), 666);
                        server.send(dp);
                    
                }
            } else if ("exit".equals(campi[0])) {
               
            } else {
                
               // data = ris.getBytes();
               
                    dp = new DatagramPacket(data, data.length, InetAddress.getByName("localhost"), 666);
                    server.send(dp);
                
            }
     
}
   
     
}
   
}
